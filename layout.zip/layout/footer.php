<br>
<br>
<br>
<footer>
    <div class="container-fluid bg-dark text-white">
        <div class="row">
            <div class="col-12">
                <p class="text-center">&copy; 2023 - All Rights Reserved by <a href="https://t.me/NHudaEi">@NHudaEi</a></p>
                <span>&nbsp;<br></span>
            </div>
        </div>
    </div>
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap/bootstrap.min.js"></script>

<!-- sticky -->
<script>
    $(window).scroll(function() {
        if ($(window).scrollTop() >= 100) {
            $('nav').addClass('fixed-header');
        } else {
            $('nav').removeClass('fixed-header');
        }
    });

    function add(id) {
        // trigger sweetalert2
        Swal.fire({
            title: 'Are you sure?',
            text: "You want to add this product to cart?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#aaa',
            confirmButtonText: 'Yes, add it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // trigger sweetalert2
                Swal.fire(
                    'Added!',
                    'Your product has been added to cart.',
                    'success'
                ).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = ""; // refresh page or redirect to another page
                    }
                })
            }
        })
    }
</script>
<style>
    .fixed-header {
        background: #fff;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 9999;
    }
</style>
</body>

</html>