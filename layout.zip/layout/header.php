<!doctype html>
<html lang="en">

<head>
    <title><?= $title ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css">
    <!-- Font -->
    <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>

    <!-- sweetalert2 cdn -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <nav class="navbar navbar-expand-sm navbar-light bg-warning">
        <a class="navbar-brand logo" href="index.php">Bakery Sweet&Co</a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item <?php if ($title == "Home") : ?>active<?php endif; ?>">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <!-- <li class="nav-item <?php if ($title == "Menu") : ?>active<?php endif; ?>">
                    <a class="nav-link" href="menu.php">Menu</a>
                </li> -->
                <!-- category have cake, pastry-->
                <li class="nav-item dropdown <?php if ($title == "Cake" || $title == "Pastry") : ?>active<?php endif; ?>">
                    <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Menu</a>
                    <div class="dropdown-menu" aria-labelledby="dropdownId">
                        <a class="dropdown-item" href="menu.php#cake">Cake</a>
                        <a class="dropdown-item" href="menu.php#pastry">Pastry</a>
                    </div>
                </li>
                <li class="nav-item <?php if ($title == "Contact") : ?>active<?php endif; ?>">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav my-2 my-lg-0">
                <li class="nav-item <?php if ($title == "Sign In" || $title == "Sign Up") : ?>active<?php endif; ?>">
                    <a class="nav-link" href="sign-in.php">Sign In / Sign Up</a>
                </li>
            </ul>
        </div>
    </nav>